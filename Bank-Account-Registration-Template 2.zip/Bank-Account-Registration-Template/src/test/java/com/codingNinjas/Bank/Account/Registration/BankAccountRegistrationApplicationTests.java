package com.codingNinjas.Bank.Account.Registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAccountRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
